package chilexplox;


public class Mensaje {
  public String contenido;
  public boolean urgente;
  //Relacionados
  

  public Mensaje(String contenido, boolean urgente)
  {
    this.contenido = contenido;
    this.urgente = urgente;
  }
}
